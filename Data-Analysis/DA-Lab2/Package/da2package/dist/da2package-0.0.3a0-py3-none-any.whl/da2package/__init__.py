"""
da2pack

An example python library.
"""

__version__ = "0.0.1-alpha"
__author__ = 'Gleb Pushkarev'
__credits__ = 'ITMO University'
