"""
da2package

An example python library.
"""

__version__ = "0.0.4-alpha"
__author__ = 'Gleb Pushkarev'
__credits__ = 'ITMO University'
